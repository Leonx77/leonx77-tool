// PWA Functionality for LeonX77
class LeonX77PWAManager {
  constructor() {
    this.deferredPrompt = null;
    this.isInstalled = false;
    
    this.init();
  }

  init() {
    this.registerServiceWorker();
    this.setupInstallPrompt();
    this.detectInstallation();
    this.setupPWAEvents();
    
    console.log('LeonX77 PWA Manager initialized 💀');
  }

  async registerServiceWorker() {
    if ('serviceWorker' in navigator) {
      try {
        const registration = await navigator.serviceWorker.register('/sw.js');
        console.log('LeonX77 Service Worker registered successfully:', registration);
        
        // Handle updates
        registration.addEventListener('updatefound', () => {
          const newWorker = registration.installing;
          if (newWorker) {
            newWorker.addEventListener('statechange', () => {
              if (newWorker.state === 'installed' && navigator.serviceWorker.controller) {
                this.showUpdateNotification();
              }
            });
          }
        });
        
        // Listen for messages from service worker
        navigator.serviceWorker.addEventListener('message', (event) => {
          this.handleServiceWorkerMessage(event);
        });
        
      } catch (error) {
        console.error('LeonX77 Service Worker registration failed:', error);
      }
    }
  }

  setupInstallPrompt() {
    window.addEventListener('beforeinstallprompt', (event) => {
      console.log('LeonX77 Before install prompt triggered');
      
      // Prevent the default install prompt
      event.preventDefault();
      
      // Store the event for later use
      this.deferredPrompt = event;
      
      // Show custom install button
      this.showInstallButton();
    });

    // Handle install button click
    const installBtn = document.getElementById('installBtn');
    if (installBtn) {
      installBtn.addEventListener('click', () => {
        this.promptInstall();
      });
    }
  }

  showInstallButton() {
    const installBtn = document.getElementById('installBtn');
    if (installBtn && !this.isInstalled) {
      installBtn.style.display = 'inline-block';
      installBtn.classList.add('bounce');
      
      // Add bounce animation
      setTimeout(() => {
        installBtn.classList.remove('bounce');
      }, 1000);
    }
  }

  hideInstallButton() {
    const installBtn = document.getElementById('installBtn');
    if (installBtn) {
      installBtn.style.display = 'none';
    }
  }

  async promptInstall() {
    if (!this.deferredPrompt) {
      this.showToast('💀 Install prompt tidak tersedia', 'warning');
      return;
    }

    try {
      // Show the install prompt
      this.deferredPrompt.prompt();
      
      // Wait for user response
      const result = await this.deferredPrompt.userChoice;
      
      if (result.outcome === 'accepted') {
        console.log('User accepted the LeonX77 install prompt');
        this.showToast('💀 LeonX77 sedang diinstall...', 'success');
      } else {
        console.log('User dismissed the LeonX77 install prompt');
        this.showToast('💀 Instalasi LeonX77 dibatalkan', 'info');
      }
      
      // Clear the deferred prompt
      this.deferredPrompt = null;
      this.hideInstallButton();
      
    } catch (error) {
      console.error('LeonX77 Install prompt error:', error);
      this.showToast('💀 Gagal menampilkan prompt install LeonX77', 'error');
    }
  }

  detectInstallation() {
    // Check if app is already installed
    if (window.matchMedia('(display-mode: standalone)').matches) {
      this.isInstalled = true;
      this.hideInstallButton();
      console.log('LeonX77 App is running in standalone mode');
    }

    // Listen for app install
    window.addEventListener('appinstalled', (event) => {
      console.log('LeonX77 App was installed successfully');
      this.isInstalled = true;
      this.hideInstallButton();
      this.showToast('💀 LeonX77 berhasil diinstall!', 'success');
      
      // Send analytics event
      this.trackInstallEvent('success');
    });
  }

  setupPWAEvents() {
    // Handle orientation changes
    window.addEventListener('orientationchange', () => {
      setTimeout(() => {
        this.adjustLayoutForOrientation();
      }, 100);
    });

    // Handle app becoming visible/hidden
    document.addEventListener('visibilitychange', () => {
      if (document.hidden) {
        console.log('LeonX77 App is hidden');
      } else {
        console.log('LeonX77 App is visible');
        this.checkForUpdates();
      }
    });

    // Handle online/offline events
    window.addEventListener('online', () => {
      console.log('LeonX77 App is online');
      this.syncOfflineData();
    });

    window.addEventListener('offline', () => {
      console.log('LeonX77 App is offline');
      this.enableOfflineMode();
    });
  }

  adjustLayoutForOrientation() {
    const orientation = screen.orientation ? screen.orientation.angle : window.orientation;
    const body = document.body;
    
    if (Math.abs(orientation) === 90) {
      // Landscape
      body.classList.add('landscape');
      body.classList.remove('portrait');
    } else {
      // Portrait
      body.classList.add('portrait');
      body.classList.remove('landscape');
    }
  }

  async checkForUpdates() {
    if ('serviceWorker' in navigator) {
      try {
        const registration = await navigator.serviceWorker.getRegistration();
        if (registration) {
          registration.update();
        }
      } catch (error) {
        console.error('LeonX77 Update check failed:', error);
      }
    }
  }

  showUpdateNotification() {
    const updateNotification = document.createElement('div');
    updateNotification.className = 'update-notification';
    updateNotification.innerHTML = `
      <div class="update-content">
        <i class="fas fa-skull"></i>
        <span>💀 LeonX77 Update tersedia! Muat ulang untuk mendapatkan versi terbaru.</span>
        <button id="updateBtn" class="btn btn-primary">Update</button>
        <button id="dismissBtn" class="btn btn-secondary">Nanti</button>
      </div>
    `;
    
    document.body.appendChild(updateNotification);
    
    // Handle update button
    document.getElementById('updateBtn').addEventListener('click', () => {
      this.applyUpdate();
    });
    
    // Handle dismiss button
    document.getElementById('dismissBtn').addEventListener('click', () => {
      updateNotification.remove();
    });
  }

  applyUpdate() {
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.getRegistration().then((registration) => {
        if (registration && registration.waiting) {
          registration.waiting.postMessage({ type: 'SKIP_WAITING' });
        }
      });
    }
    
    // Reload the page
    window.location.reload();
  }

  handleServiceWorkerMessage(event) {
    const { type, data } = event.data || {};
    
    switch (type) {
      case 'SYNC_SUCCESS':
        console.log('LeonX77 Background sync successful:', data);
        this.showToast('💀 Data LeonX77 berhasil disinkronisasi', 'success');
        break;
        
      case 'CACHE_UPDATED':
        console.log('LeonX77 Cache updated');
        break;
        
      default:
        console.log('Unknown LeonX77 service worker message:', event.data);
    }
  }

  async syncOfflineData() {
    console.log('Syncing LeonX77 offline data...');
    
    try {
      // Check if there's any offline data to sync
      const offlineData = localStorage.getItem('leonx77-offline-data');
      if (offlineData) {
        const data = JSON.parse(offlineData);
        
        // Process offline data
        // This would typically send pending requests to the server
        console.log('Processing LeonX77 offline data:', data);
        
        // Clear offline data after successful sync
        localStorage.removeItem('leonx77-offline-data');
        
        this.showToast('💀 Data offline LeonX77 berhasil disinkronisasi', 'success');
      }
    } catch (error) {
      console.error('LeonX77 Offline sync failed:', error);
      this.showToast('💀 Gagal menyinkronkan data offline LeonX77', 'error');
    }
  }

  enableOfflineMode() {
    console.log('Enabling LeonX77 offline mode...');
    
    // Add offline indicator
    const offlineIndicator = document.createElement('div');
    offlineIndicator.id = 'offlineIndicator';
    offlineIndicator.className = 'offline-indicator';
    offlineIndicator.innerHTML = `
      <i class="fas fa-skull"></i>
      <span>💀 LeonX77 Mode Offline</span>
    `;
    
    document.body.appendChild(offlineIndicator);
    
    // Store current state for offline use
    this.saveOfflineState();
  }

  saveOfflineState() {
    try {
      const offlineData = {
        timestamp: Date.now(),
        url: window.location.href,
        userAgent: navigator.userAgent
      };
      
      localStorage.setItem('leonx77-offline-data', JSON.stringify(offlineData));
    } catch (error) {
      console.error('Failed to save LeonX77 offline state:', error);
    }
  }

  trackInstallEvent(status) {
    console.log('LeonX77 Install event tracked:', status);
    
    // This would typically send analytics data
    const eventData = {
      event: 'leonx77_pwa_install',
      status: status,
      timestamp: Date.now(),
      userAgent: navigator.userAgent
    };
    
    console.log('LeonX77 Analytics event:', eventData);
  }

  showToast(message, type = 'info') {
    // Use the same toast system as the main app
    if (window.leonX77App) {
      window.leonX77App.showToast(message, type);
    } else {
      console.log(`LeonX77 Toast: ${message} (${type})`);
    }
  }

  // Public API
  getInstallStatus() {
    return {
      isInstalled: this.isInstalled,
      canInstall: !!this.deferredPrompt,
      isStandalone: window.matchMedia('(display-mode: standalone)').matches
    };
  }

  async getStorageUsage() {
    if ('storage' in navigator && 'estimate' in navigator.storage) {
      try {
        const estimate = await navigator.storage.estimate();
        return {
          quota: estimate.quota,
          usage: estimate.usage,
          usagePercentage: (estimate.usage / estimate.quota * 100).toFixed(2)
        };
      } catch (error) {
        console.error('LeonX77 Storage estimate failed:', error);
        return null;
      }
    }
    return null;
  }
}

// Initialize LeonX77 PWA Manager
document.addEventListener('DOMContentLoaded', () => {
  window.leonX77PWAManager = new LeonX77PWAManager();
});

// Add CSS for LeonX77 PWA-specific styles
const leonX77PWAStyles = `
  .bounce {
    animation: leonx77-bounce 1s infinite;
  }
  
  @keyframes leonx77-bounce {
    0%, 20%, 50%, 80%, 100% {
      transform: translateY(0);
    }
    40% {
      transform: translateY(-10px);
    }
    60% {
      transform: translateY(-5px);
    }
  }
  
  .update-notification {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    background: linear-gradient(135deg, #FFD700, #DAA520);
    color: #000;
    padding: 16px;
    z-index: 10000;
    box-shadow: 0 2px 20px rgba(255, 215, 0, 0.5);
    border-bottom: 3px solid #000;
  }
  
  .update-content {
    display: flex;
    align-items: center;
    gap: 12px;
    max-width: 1200px;
    margin: 0 auto;
    font-weight: bold;
  }
  
  .update-content .btn {
    padding: 8px 16px;
    font-size: 0.9rem;
    font-weight: bold;
  }
  
  .offline-indicator {
    position: fixed;
    top: 20px;
    left: 20px;
    background: linear-gradient(135deg, #FFD700, #DAA520);
    color: #000;
    padding: 8px 16px;
    border-radius: 20px;
    z-index: 1000;
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 0.9rem;
    font-weight: 600;
    border: 2px solid #000;
    box-shadow: 0 4px 15px rgba(255, 215, 0, 0.4);
  }
  
  .landscape {
    /* LeonX77 Landscape-specific styles */
  }
  
  .portrait {
    /* LeonX77 Portrait-specific styles */
  }
  
  @media (display-mode: standalone) {
    .leonx77-pwa-only {
      display: block !important;
    }
    
    body {
      -webkit-user-select: none;
      -webkit-touch-callout: none;
      -webkit-tap-highlight-color: transparent;
    }
  }
`;

// Inject LeonX77 PWA styles
const leonX77StyleSheet = document.createElement('style');
leonX77StyleSheet.textContent = leonX77PWAStyles;
document.head.appendChild(leonX77StyleSheet);