// LeonX77 Tool Main Application
class LeonX77App {
  constructor() {
    this.isRunning = false;
    this.progress = 0;
    this.maxProgress = 5000;
    this.successCount = 0;
    this.errorCount = 0;
    this.intervalId = null;
    this.jsonPayload = '';
    this.isPayloadVisible = false;
    
    this.init();
  }

  init() {
    this.bindEvents();
    this.updateConnectionStatus();
    this.loadSavedData();
    this.updateUI();
    
    // Check for URL parameters
    this.handleURLParams();
    
    console.log('LeonX77 Tool initialized successfully 💀');
    this.addLog('🔥 LeonX77 Tool siap digunakan', 'info');
  }

  bindEvents() {
    // Control buttons
    document.getElementById('runBtn').addEventListener('click', () => this.startScript());
    document.getElementById('stopBtn').addEventListener('click', () => this.stopScript());
    
    // Payload toggle
    document.getElementById('togglePayload').addEventListener('click', () => this.togglePayload());
    
    // Payload input
    document.getElementById('jsonPayload').addEventListener('input', (e) => {
      this.jsonPayload = e.target.value;
      this.saveData();
    });
    
    // Clear log
    document.getElementById('clearLog').addEventListener('click', () => this.clearLog());
    
    // Connection status
    window.addEventListener('online', () => this.updateConnectionStatus());
    window.addEventListener('offline', () => this.updateConnectionStatus());
    
    // Keyboard shortcuts
    document.addEventListener('keydown', (e) => this.handleKeyboardShortcuts(e));
    
    // Visibility change (for PWA lifecycle)
    document.addEventListener('visibilitychange', () => this.handleVisibilityChange());
  }

  handleURLParams() {
    const urlParams = new URLSearchParams(window.location.search);
    const action = urlParams.get('action');
    
    if (action === 'run') {
      this.showToast('💀 Shortcut LeonX77: Memulai script...', 'info');
      setTimeout(() => this.startScript(), 1000);
    }
  }

  handleKeyboardShortcuts(e) {
    // Ctrl/Cmd + Enter: Run script
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
      e.preventDefault();
      if (!this.isRunning) {
        this.startScript();
      }
    }
    
    // Escape: Stop script
    if (e.key === 'Escape' && this.isRunning) {
      e.preventDefault();
      this.stopScript();
    }
    
    // Ctrl/Cmd + L: Clear log
    if ((e.ctrlKey || e.metaKey) && e.key === 'l') {
      e.preventDefault();
      this.clearLog();
    }
  }

  handleVisibilityChange() {
    if (document.hidden) {
      // App is hidden
      this.saveData();
    } else {
      // App is visible
      this.updateLastUpdate();
    }
  }

  togglePayload() {
    this.isPayloadVisible = !this.isPayloadVisible;
    const toggleBtn = document.getElementById('togglePayload');
    const payloadHidden = document.getElementById('payloadHidden');
    const payloadInput = document.getElementById('jsonPayload');
    
    if (this.isPayloadVisible) {
      toggleBtn.innerHTML = '<i class="fas fa-eye-slash"></i> Hide';
      payloadHidden.style.display = 'none';
      payloadInput.style.display = 'block';
      payloadInput.focus();
    } else {
      toggleBtn.innerHTML = '<i class="fas fa-eye"></i> Show';
      payloadHidden.style.display = 'block';
      payloadInput.style.display = 'none';
    }
  }

  startScript() {
    if (this.isRunning) return;
    
    // Validate JSON payload
    if (!this.validateJSON()) {
      this.showToast('💀 JSON payload tidak valid atau kosong!', 'error');
      return;
    }
    
    this.isRunning = true;
    this.progress = 0;
    this.successCount = 0;
    this.errorCount = 0;
    
    this.updateUI();
    this.addLog('💀 LeonX77 Script dimulai...', 'info');
    this.addLog(`📊 Target: ${this.maxProgress} requests`, 'info');
    this.addLog(`📋 Payload: ${this.jsonPayload.length} karakter`, 'info');
    this.addLog('🔥 Mode LeonX77 aktif!', 'warning');
    
    // Hide payload when running
    if (this.isPayloadVisible) {
      this.togglePayload();
    }
    
    // Show loading overlay briefly
    this.showLoading();
    setTimeout(() => this.hideLoading(), 1000);
    
    // Start the main loop
    this.intervalId = setInterval(() => {
      this.executeRequest();
    }, 100); // Execute every 100ms
    
    this.showToast('💀 LeonX77 Script dimulai!', 'success');
  }

  stopScript() {
    if (!this.isRunning) return;
    
    this.isRunning = false;
    
    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }
    
    this.updateUI();
    this.addLog('⛔ Script dihentikan oleh user', 'warning');
    this.addLog(`📈 Final stats: ${this.successCount} success, ${this.errorCount} errors`, 'info');
    this.addLog('💀 LeonX77 mode deaktivasi', 'info');
    
    this.showToast('💀 LeonX77 Script dihentikan!', 'warning');
  }

  async executeRequest() {
    try {
      // Simulate API request with LeonX77 theme
      const isSuccess = Math.random() > 0.15; // 85% success rate (LeonX77 power!)
      
      if (isSuccess) {
        this.successCount++;
        const messages = [
          `💀 LeonX77 Request #${this.progress + 1} berhasil`,
          `🔥 Sukses attack #${this.progress + 1}`,
          `⚡ LeonX77 strike #${this.progress + 1} hit!`,
          `💎 Golden request #${this.progress + 1} complete`
        ];
        this.addLog(messages[Math.floor(Math.random() * messages.length)], 'success');
      } else {
        this.errorCount++;
        const messages = [
          `💀 Request #${this.progress + 1} gagal`,
          `⚠️ LeonX77 attack #${this.progress + 1} blocked`,
          `🛡️ Defense detected #${this.progress + 1}`,
          `🔒 Request #${this.progress + 1} timeout`
        ];
        this.addLog(messages[Math.floor(Math.random() * messages.length)], 'error');
      }
      
      this.progress++;
      this.updateProgress();
      
      // Check if completed
      if (this.progress >= this.maxProgress) {
        this.completeScript();
      }
      
    } catch (error) {
      this.errorCount++;
      this.addLog(`💥 LeonX77 Error: ${error.message}`, 'error');
      console.error('Request error:', error);
    }
  }

  completeScript() {
    this.isRunning = false;
    
    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }
    
    this.updateUI();
    this.addLog('🎉 LeonX77 Script selesai dijalankan!', 'success');
    this.addLog(`📊 Total: ${this.successCount} success, ${this.errorCount} errors`, 'info');
    this.addLog('💀 LeonX77 mission complete!', 'success');
    
    // Show completion notification
    this.showToast(`💀 LeonX77 selesai! ${this.successCount} berhasil, ${this.errorCount} gagal`, 'success');
    
    // Send notification if supported
    this.sendNotification('LeonX77 Script Selesai', `${this.successCount} berhasil, ${this.errorCount} gagal`);
  }

  validateJSON() {
    const payload = document.getElementById('jsonPayload').value.trim();
    
    if (!payload) {
      return false;
    }
    
    try {
      JSON.parse(payload);
      this.jsonPayload = payload;
      return true;
    } catch (error) {
      return false;
    }
  }

  updateProgress() {
    const percentage = (this.progress / this.maxProgress) * 100;
    
    // Update progress bar
    document.getElementById('progressFill').style.width = `${percentage}%`;
    
    // Update progress text
    document.getElementById('progressText').textContent = 
      `${this.progress} / ${this.maxProgress} (${percentage.toFixed(1)}%)`;
    
    // Update stats
    document.getElementById('successCount').textContent = this.successCount;
    document.getElementById('errorCount').textContent = this.errorCount;
    
    // Update last update time
    this.updateLastUpdate();
  }

  updateUI() {
    const runBtn = document.getElementById('runBtn');
    const stopBtn = document.getElementById('stopBtn');
    
    if (this.isRunning) {
      runBtn.disabled = true;
      stopBtn.disabled = false;
      runBtn.innerHTML = '<i class="fas fa-skull fa-spin"></i> RUNNING...';
    } else {
      runBtn.disabled = false;
      stopBtn.disabled = true;
      runBtn.innerHTML = '<i class="fas fa-rocket"></i> RUN SCRIPT';
    }
  }

  addLog(message, type = 'info') {
    const logOutput = document.getElementById('logOutput');
    const timestamp = new Date().toLocaleTimeString('id-ID');
    
    // Remove placeholder if exists
    const placeholder = logOutput.querySelector('.log-placeholder');
    if (placeholder) {
      placeholder.remove();
    }
    
    // Create log entry
    const logEntry = document.createElement('div');
    logEntry.className = `log-entry ${type}`;
    logEntry.innerHTML = `<span class="timestamp">[${timestamp}]</span> ${message}`;
    
    // Add to log output
    logOutput.appendChild(logEntry);
    
    // Auto-scroll to bottom
    logOutput.scrollTop = logOutput.scrollHeight;
    
    // Limit log entries (keep last 1000)
    const entries = logOutput.querySelectorAll('.log-entry');
    if (entries.length > 1000) {
      entries[0].remove();
    }
  }

  clearLog() {
    const logOutput = document.getElementById('logOutput');
    logOutput.innerHTML = `
      <p class="log-placeholder">
        <i class="fas fa-skull"></i> Log LeonX77 akan muncul di sini saat eksekusi dimulai
      </p>
    `;
    this.showToast('💀 Log LeonX77 dibersihkan', 'info');
  }

  showLoading() {
    document.getElementById('loadingOverlay').style.display = 'flex';
  }

  hideLoading() {
    document.getElementById('loadingOverlay').style.display = 'none';
  }

  showToast(message, type = 'info') {
    const toastContainer = document.getElementById('toastContainer');
    
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.innerHTML = `
      <div style="display: flex; align-items: center; gap: 8px;">
        <i class="fas fa-${this.getToastIcon(type)}"></i>
        <span>${message}</span>
      </div>
    `;
    
    toastContainer.appendChild(toast);
    
    // Auto remove after 3 seconds
    setTimeout(() => {
      toast.remove();
    }, 3000);
  }

  getToastIcon(type) {
    const icons = {
      success: 'check-circle',
      error: 'exclamation-triangle',
      warning: 'exclamation-circle',
      info: 'skull'
    };
    return icons[type] || 'skull';
  }

  updateConnectionStatus() {
    const statusElement = document.getElementById('connectionStatus');
    const isOnline = navigator.onLine;
    
    statusElement.textContent = isOnline ? 'Online' : 'Offline';
    statusElement.style.color = isOnline ? '#32CD32' : '#FF4444';
    
    if (!isOnline) {
      this.showToast('💀 LeonX77 sedang offline. Beberapa fitur mungkin tidak tersedia.', 'warning');
    }
  }

  updateLastUpdate() {
    const lastUpdateElement = document.getElementById('lastUpdate');
    lastUpdateElement.textContent = new Date().toLocaleTimeString('id-ID');
  }

  saveData() {
    try {
      const data = {
        jsonPayload: this.jsonPayload,
        progress: this.progress,
        successCount: this.successCount,
        errorCount: this.errorCount,
        timestamp: Date.now()
      };
      
      localStorage.setItem('leonx77-data', JSON.stringify(data));
    } catch (error) {
      console.error('Failed to save LeonX77 data:', error);
    }
  }

  loadSavedData() {
    try {
      const savedData = localStorage.getItem('leonx77-data');
      if (savedData) {
        const data = JSON.parse(savedData);
        
        // Load JSON payload
        if (data.jsonPayload) {
          this.jsonPayload = data.jsonPayload;
          document.getElementById('jsonPayload').value = this.jsonPayload;
        }
        
        // Don't restore progress if it's from a previous session
        const timeDiff = Date.now() - (data.timestamp || 0);
        if (timeDiff < 5 * 60 * 1000) { // 5 minutes
          this.progress = data.progress || 0;
          this.successCount = data.successCount || 0;
          this.errorCount = data.errorCount || 0;
          this.updateProgress();
        }
      }
    } catch (error) {
      console.error('Failed to load saved LeonX77 data:', error);
    }
  }

  async sendNotification(title, body) {
    // Check if notifications are supported
    if (!('Notification' in window)) {
      return;
    }
    
    // Request permission if not granted
    if (Notification.permission === 'default') {
      await Notification.requestPermission();
    }
    
    // Send notification if permission granted
    if (Notification.permission === 'granted') {
      new Notification(title, {
        body: body,
        icon: '/icons/icon-192x192.png',
        badge: '/icons/icon-192x192.png',
        tag: 'leonx77-notification'
      });
    }
  }

  // Public API for external access
  getStats() {
    return {
      progress: this.progress,
      maxProgress: this.maxProgress,
      successCount: this.successCount,
      errorCount: this.errorCount,
      isRunning: this.isRunning
    };
  }
}

// Initialize app when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
  window.leonX77App = new LeonX77App();
});

// Global error handler
window.addEventListener('error', (event) => {
  console.error('Global error:', event.error);
  if (window.leonX77App) {
    window.leonX77App.addLog(`💥 LeonX77 Global error: ${event.error.message}`, 'error');
  }
});

// Handle unhandled promise rejections
window.addEventListener('unhandledrejection', (event) => {
  console.error('Unhandled promise rejection:', event.reason);
  if (window.leonX77App) {
    window.leonX77App.addLog(`💥 LeonX77 Promise rejection: ${event.reason}`, 'error');
  }
});