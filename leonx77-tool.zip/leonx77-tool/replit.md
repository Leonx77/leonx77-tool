# Replit Project Documentation

## Overview

LeonX77 Tool is a Progressive Web App (PWA) that converts to native Android APK using GitHub Actions automation. The project features LeonX77 branding with dark theme, golden accents, and custom skull icons. It supports ARM32 and ARM64 Android architectures with automatic build generation.

## System Architecture

**Current Architecture**: PWA to Native Android APK Conversion System

**Components**:
- **Frontend**: Progressive Web App with vanilla HTML5, CSS3, JavaScript ES6+
- **PWA Features**: Service Worker, Web App Manifest, offline support
- **Build System**: GitHub Actions with Capacitor framework
- **APK Generation**: Multi-architecture support (ARM32, ARM64, Universal)
- **Branding**: LeonX77 dark theme with golden accents and skull icons

## Key Components

**Implemented Components**:
- **PWA Core**: `index.html`, `manifest.json`, `sw.js`
- **Styling**: `css/style.css` with LeonX77 branding
- **JavaScript**: `js/app.js` (main app logic), `js/pwa.js` (PWA features)
- **Icons**: SVG-based custom skull icons for multiple sizes
- **Build Pipeline**: `.github/workflows/build-apk.yml` for automated APK generation
- **Configuration**: `capacitor.config.ts` for native app settings

## Data Flow

**Current State**: No data flow established.

**Planning Considerations**:
- Define how data moves between client and server
- Plan for data validation at multiple layers
- Consider caching strategies for performance
- Design error handling and logging mechanisms

## External Dependencies

**Current State**: No external dependencies identified.

**Common Dependencies to Consider**:
- Database systems (PostgreSQL recommended for use with Drizzle ORM)
- Authentication services
- Third-party APIs
- Frontend frameworks and libraries
- Backend frameworks and middleware

## Deployment Strategy

**Current State**: No deployment strategy established.

**Recommendations**:
- Use Replit's built-in deployment features for rapid prototyping
- Consider containerization (Docker) for production deployments
- Plan for environment-specific configurations
- Implement CI/CD pipelines as the project grows

## Changelog

```
Changelog:
- July 04, 2025. Initial setup
```

## User Preferences

```
Preferred communication style: Simple, everyday language.
```

## Next Steps

Since this is a fresh repository, consider:

1. **Project Initialization**: Set up basic project structure and package management
2. **Technology Stack Selection**: Choose appropriate frontend/backend technologies
3. **Database Setup**: If data persistence is needed, consider PostgreSQL with Drizzle ORM
4. **Development Environment**: Configure development tools and dependencies
5. **Basic Architecture**: Implement foundational components and folder structure

This document will be updated as architectural decisions are made and the project evolves.