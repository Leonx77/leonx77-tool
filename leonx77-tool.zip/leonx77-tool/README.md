# LeonX77 Tool - PWA to APK

💀 LeonX77 Tool adalah Progressive Web App yang dapat dikonversi menjadi APK Android asli menggunakan GitHub Actions.

## ✨ Fitur Utama

- 💀 **Dark Theme** dengan aksen emas LeonX77
- 📱 **Progressive Web App** yang dapat diinstall
- 🔧 **JSON Payload Input** untuk script automation
- 📊 **Progress Tracking** real-time
- 📝 **Logging System** dengan berbagai level
- 🌐 **Offline Support** penuh
- 🔄 **Auto-sync** saat kembali online
- 📱 **Push Notifications** support
- ⚡ **Service Worker** untuk performance

## 🚀 Quick Start

### Demo Online
PWA tersedia di: `https://yourusername.github.io/leonx77-tool`

### Build APK Android
1. **Fork repository** ini
2. **Enable GitHub Actions** di Settings
3. **Run workflow** "Build LeonX77 Android APK"
4. **Download APK** dari Artifacts setelah build selesai
5. **Install di HP Android**

## 📱 Spesifikasi APK

- **App Name**: LeonX77Tool
- **Package**: com.leonx77
- **Min Android**: 5.0 (API 21)
- **Architectures**: ARM32 + ARM64 + Universal
- **Size**: 8-12MB (tergantung variant)

### APK Variants:
1. **ARM32 (armeabi-v7a)** - untuk HP Android lama (2013-2017)
2. **ARM64 (arm64-v8a)** - untuk HP Android modern (2018+)
3. **Universal APK** - kompatibel dengan semua HP Android

## 📖 Tutorial Lengkap

Baca file `TUTORIAL_LENGKAP_PEMULA.md` untuk panduan step-by-step dari awal sampai install APK di HP Android.

## 🔧 Kustomisasi

### Ganti Nama App & Package
Edit file `.github/workflows/build-apk.yml`:
```yaml
appName: 'NamaAppAnda'
appId: 'com.namaanda.aplikasi'
```

### Ganti Icon
Replace file di folder `icons/` dengan icon custom Anda.

### Ganti Tema
Edit file `css/style.css` untuk mengubah warna dan styling.

## ⚡ Auto-Build

APK akan dibuild otomatis setiap kali:
- Push ke branch `main`
- Membuat release baru
- Manual trigger via Actions tab

## 🔄 Update APK

1. Edit file di GitHub
2. Push perubahan
3. Wait for auto-build
4. Download APK baru dari Artifacts
5. Install update di HP

## 📞 Support

Jika ada masalah:
1. Cek tab Actions untuk error logs
2. Pastikan semua file PWA lengkap
3. Test PWA di browser dulu sebelum build APK
4. Enable Unknown Sources di Android untuk install

## 🏗️ Tech Stack

- **Frontend**: HTML5, CSS3, JavaScript ES6+
- **PWA**: Service Worker, Web App Manifest
- **Build**: GitHub Actions, Capacitor
- **Android**: Native APK via Capacitor

## 📄 License

MIT License - Free to use and modify

---

💀 **LeonX77 Tool** - From PWA to APK in minutes!