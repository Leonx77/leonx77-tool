#!/usr/bin/env python3
"""
Create LeonX77 icons based on the skull and golden design
"""

from PIL import Image, ImageDraw, ImageFont
import os

def create_leonx77_icon(size, filename):
    """Create LeonX77 icon with skull and golden theme"""
    
    # Create image with black background
    img = Image.new('RGBA', (size, size), (0, 0, 0, 255))
    draw = ImageDraw.Draw(img)
    
    # Add rounded corners
    mask = Image.new('L', (size, size), 0)
    mask_draw = ImageDraw.Draw(mask)
    corner_radius = size // 8
    mask_draw.rounded_rectangle((0, 0, size, size), corner_radius, fill=255)
    
    # Apply mask for rounded corners
    img.putalpha(mask)
    
    # Colors
    gold = (255, 215, 0, 255)  # Gold color
    dark_gold = (218, 165, 32, 255)  # Darker gold
    white = (255, 255, 255, 255)
    gray = (169, 169, 169, 255)
    
    center = size // 2
    
    # Draw skull outline (simplified)
    skull_width = size // 2
    skull_height = int(size * 0.4)
    skull_top = size // 4
    
    # Main skull shape (oval)
    skull_bbox = [
        center - skull_width//2,
        skull_top,
        center + skull_width//2,
        skull_top + skull_height
    ]
    draw.ellipse(skull_bbox, fill=gray)
    
    # Eye sockets (black holes)
    eye_size = skull_width // 6
    left_eye_x = center - skull_width//4
    right_eye_x = center + skull_width//4
    eye_y = skull_top + skull_height//3
    
    # Left eye socket
    draw.ellipse([
        left_eye_x - eye_size//2,
        eye_y - eye_size//2,
        left_eye_x + eye_size//2,
        eye_y + eye_size//2
    ], fill=(0, 0, 0, 255))
    
    # Right eye socket
    draw.ellipse([
        right_eye_x - eye_size//2,
        eye_y - eye_size//2,
        right_eye_x + eye_size//2,
        eye_y + eye_size//2
    ], fill=(0, 0, 0, 255))
    
    # Nasal cavity (triangular)
    nose_points = [
        (center, eye_y + eye_size),
        (center - eye_size//3, skull_top + int(skull_height * 0.7)),
        (center + eye_size//3, skull_top + int(skull_height * 0.7))
    ]
    draw.polygon(nose_points, fill=(0, 0, 0, 255))
    
    # Teeth/jaw area
    jaw_y = skull_top + int(skull_height * 0.8)
    tooth_width = skull_width // 8
    for i in range(4):
        tooth_x = center - skull_width//3 + i * tooth_width
        draw.rectangle([
            tooth_x,
            jaw_y,
            tooth_x + tooth_width//2,
            jaw_y + size//20
        ], fill=white)
    
    # Golden accents on sides (simplified hands/bones)
    accent_size = size // 10
    left_accent_x = size // 8
    right_accent_x = size - size // 8
    accent_y = center
    
    # Left golden accent
    draw.ellipse([
        left_accent_x - accent_size,
        accent_y - accent_size,
        left_accent_x + accent_size,
        accent_y + accent_size
    ], fill=gold)
    
    # Right golden accent
    draw.ellipse([
        right_accent_x - accent_size,
        right_accent_x - accent_size,
        right_accent_x + accent_size,
        accent_y + accent_size
    ], fill=gold)
    
    # Text "Leon X 77" at bottom if icon is large enough
    if size >= 192:
        try:
            font = ImageFont.load_default()
            text = "Leon X 77"
            
            # Get text dimensions
            text_bbox = draw.textbbox((0, 0), text, font=font)
            text_width = text_bbox[2] - text_bbox[0]
            text_height = text_bbox[3] - text_bbox[1]
            
            text_x = (size - text_width) // 2
            text_y = size - size // 6
            
            # Draw text with golden color
            draw.text((text_x, text_y), text, fill=gold, font=font)
        except:
            pass
    
    # Add golden border
    border_width = max(2, size // 50)
    draw.rectangle([0, 0, size, border_width], fill=gold)  # Top
    draw.rectangle([0, 0, border_width, size], fill=gold)  # Left
    draw.rectangle([size-border_width, 0, size, size], fill=gold)  # Right
    draw.rectangle([0, size-border_width, size, size], fill=gold)  # Bottom
    
    # Save the image
    img.save(filename, 'PNG')
    print(f"Created {filename} ({size}x{size})")

def main():
    # Create icons directory
    if not os.path.exists('icons'):
        os.makedirs('icons')
    
    # Create icons
    create_leonx77_icon(192, 'icons/icon-192x192.png')
    create_leonx77_icon(512, 'icons/icon-512x512.png')
    
    print("LeonX77 icons created successfully!")

if __name__ == "__main__":
    main()