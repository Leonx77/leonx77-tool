# Tutorial Lengkap: PWA LeonX77 ke APK Android untuk Pemula

## 📱 Apa yang Akan Anda Dapatkan

Setelah mengikuti tutorial ini, Anda akan memiliki:
- **File APK Android asli** dengan nama "LeonX77Tool"
- **Package name**: `com.leonx77`
- **Aplikasi yang bisa diinstall** di HP Android seperti aplikasi Play Store
- **Icon LeonX77** di home screen Android
- **Proses build otomatis** setiap kali ada perubahan code

---

## 📋 Persiapan Awal (Yang Dibutuhkan)

### 1. Akun GitHub (Gratis)
- Daftar di: https://github.com
- Confirm email Anda
- Login ke GitHub

### 2. Browser Modern
- Chrome, Firefox, atau Safari terbaru
- Koneksi internet stabil

### 3. HP Android (untuk testing)
- Android 5.0+ (API 21+)
- Space kosong minimal 20MB

---

## 🚀 LANGKAH 1: Buat Repository di GitHub

### A. Buat Repository Baru
1. Login ke GitHub
2. Klik tombol **"New"** (hijau) di kiri atas
3. Repository name: `leonx77-tool`
4. Description: `LeonX77 Tool PWA to APK`
5. Pilih **"Public"**
6. Centang **"Add a README file"**
7. Klik **"Create repository"**

### B. Screenshot Hasil
Anda akan melihat repository baru dengan URL seperti:
`https://github.com/USERNAME/leonx77-tool`

---

## 🚀 LANGKAH 2: Upload File PWA

### A. Download File dari Replit
1. Di Replit ini, klik **"Files"** (ikon folder)
2. Klik menu **3 titik (...)**
3. Pilih **"Download as ZIP"** atau **"Export"**
4. Extract file ZIP ke folder komputer

### B. Upload ke GitHub (Cara Web)
1. Buka repository GitHub Anda
2. Klik **"uploading an existing file"**
3. Drag & drop semua file dari folder yang sudah di-extract:
   - `index.html`
   - `manifest.json`
   - `sw.js`
   - Folder `css/` (dengan isi `style.css`)
   - Folder `js/` (dengan isi `app.js` dan `pwa.js`)
   - Folder `icons/` (dengan isi SVG files)
   - Folder `.github/workflows/` (dengan isi `build-apk.yml`)
4. Commit message: `Add LeonX77 PWA files`
5. Klik **"Commit changes"**

### C. Alternatif: Upload Manual File per File
Jika upload sekaligus tidak bisa:
1. Klik **"Create new file"**
2. Copy-paste isi dari setiap file di Replit
3. Simpan dengan nama file yang sama
4. Ulangi untuk semua file

---

## 🚀 LANGKAH 3: Aktivasi GitHub Actions

### A. Enable GitHub Actions
1. Di repository GitHub, klik tab **"Actions"**
2. Jika muncul pesan, klik **"I understand my workflows, enable them"**

### B. Set Permissions
1. Klik **"Settings"** (tab di atas)
2. Scroll ke **"Actions"** → **"General"**
3. Di bagian **"Workflow permissions"**:
   - Pilih **"Read and write permissions"**
   - Centang **"Allow GitHub Actions to create and approve pull requests"**
4. Klik **"Save"**

---

## 🚀 LANGKAH 4: Build APK Pertama

### A. Trigger Build Manual
1. Kembali ke tab **"Actions"**
2. Klik workflow **"Build LeonX77 Android APK"**
3. Klik tombol **"Run workflow"** (kanan)
4. Klik **"Run workflow"** lagi (hijau)

### B. Tunggu Proses Build
- Waktu: 10-15 menit
- Status: 🟡 Running → ✅ Success / ❌ Failed
- Jangan tutup browser, tapi bisa buka tab lain

### C. Monitor Progress
Anda akan melihat step-by-step:
1. ✅ Checkout repository
2. ✅ Setup Node.js
3. ✅ Setup Java
4. ✅ Setup Android SDK
5. ✅ Install Capacitor CLI
6. ✅ Initialize Capacitor
7. ✅ Add Android platform
8. ✅ Build APK
9. ✅ Upload APK Artifact

---

## 🚀 LANGKAH 5: Download APK

### A. Setelah Build Selesai (Ada tanda ✅)
1. Klik pada workflow yang sudah selesai
2. Scroll ke bawah sampai bagian **"Artifacts"**
3. Anda akan melihat **3 jenis APK** yang tersedia:
   - **LeonX77Tool-ARM32-APK** - untuk HP Android lama (2013-2017)
   - **LeonX77Tool-ARM64-APK** - untuk HP Android baru (2018+)
   - **LeonX77Tool-Universal-APK** - kompatibel dengan semua HP

### B. Pilih APK yang Sesuai
**Rekomendasi:**
- **Universal APK** - **PILIHAN TERBAIK** untuk pemula (works di semua HP)
- **ARM64 APK** - jika HP Android modern (Samsung S9+, Xiaomi Mi 8+, dll)
- **ARM32 APK** - jika HP Android lama (Samsung S7-, Xiaomi Mi 6-, dll)

### C. Download APK
1. Klik salah satu APK (disarankan **Universal APK**)
2. Download file ZIP
3. Extract ZIP untuk mendapatkan file `.apk`

### D. Verifikasi File APK
- **ARM32**: `LeonX77Tool-v1.0.0-arm32-debug.apk` (~8MB)
- **ARM64**: `LeonX77Tool-v1.0.0-arm64-debug.apk` (~10MB)
- **Universal**: `LeonX77Tool-v1.0.0-universal-debug.apk` (~12MB)

---

## 🚀 LANGKAH 6: Install di HP Android

### A. Transfer APK ke HP
**Cara 1: Google Drive**
1. Upload APK ke Google Drive
2. Download dari HP Android

**Cara 2: Cable USB**
1. Connect HP ke komputer
2. Copy APK ke folder Download HP

**Cara 3: Email**
1. Kirim APK via email ke diri sendiri
2. Download dari HP

### B. Enable Unknown Sources
1. Buka **Settings** HP Android
2. Cari **"Security"** atau **"Privacy"**
3. Cari **"Install unknown apps"** atau **"Unknown sources"**
4. Enable untuk **Chrome**, **Files**, atau app yang akan membuka APK

### C. Install APK
1. Buka file manager HP
2. Cari file `LeonX77Tool-v1.0.0-debug.apk`
3. Tap file APK
4. Klik **"Install"**
5. Klik **"Open"** atau cari di app drawer

### D. Verifikasi Instalasi
- Icon **LeonX77Tool** muncul di home screen
- Aplikasi buka tanpa error
- Interface gelap dengan aksen emas
- Semua fitur berfungsi normal

---

## 🔄 Update dan Maintenance

### A. Auto-Build
Setiap kali Anda:
- Push perubahan ke branch `main`
- Edit file via GitHub web
- Upload file baru

APK akan di-build ulang otomatis!

### B. Download APK Terbaru
1. Buka tab **"Actions"**
2. Klik build terbaru yang ✅ Success
3. Download dari **"Artifacts"**

### C. Update App di HP
1. Uninstall versi lama
2. Install APK baru
3. Atau install langsung (akan replace otomatis)

---

## 🎯 Kustomisasi APK

### A. Ganti Nama App
Edit file `.github/workflows/build-apk.yml`:
```yaml
appName: 'NamaAppAnda'
```

### B. Ganti Package Name
Edit file `.github/workflows/build-apk.yml`:
```yaml
appId: 'com.namaanda.aplikasi'
```

### C. Ganti Icon
1. Replace file di folder `icons/`
2. Push ke GitHub
3. Wait for auto-build

---

## 🔧 Troubleshooting

### Build Gagal ❌
**Solusi:**
1. Cek tab Actions untuk error detail
2. Pastikan semua file sudah ter-upload
3. Pastikan `manifest.json` valid (cek di jsonlint.com)
4. Re-run workflow

### APK Tidak Bisa Install
**Solusi:**
1. Enable "Unknown Sources" di Android
2. Pastikan Android 5.0+
3. Restart HP
4. Download ulang APK

### App Crash Saat Dibuka
**Solusi:**
1. Test PWA di browser dulu
2. Pastikan semua file JavaScript valid
3. Cek console error di browser (F12)
4. Build ulang APK

### File Missing saat Upload
**Solusi:**
1. Pastikan struktur folder benar:
```
leonx77-tool/
├── index.html
├── manifest.json
├── sw.js
├── css/style.css
├── js/app.js
├── js/pwa.js
├── icons/icon-*.svg
└── .github/workflows/build-apk.yml
```

---

## 📊 Spesifikasi APK yang Dihasilkan

### Technical Details:
- **App Name**: LeonX77Tool
- **Package**: com.leonx77
- **Min Android**: 5.0 (API 21)
- **Target Android**: Latest
- **Architectures**: ARM32 + ARM64 + Universal
- **Permissions**: Internet, Network State, Vibrate

### APK Variants:
1. **ARM32 (armeabi-v7a)** - ~8MB
   - HP Android lama (2013-2017)
   - Samsung Galaxy S7 dan sebelumnya
   - Xiaomi Mi 6 dan sebelumnya
   - Processor 32-bit ARM

2. **ARM64 (arm64-v8a)** - ~10MB
   - HP Android modern (2018+)
   - Samsung Galaxy S8+, Note 8+
   - Xiaomi Mi 8+, Redmi Note 5+
   - Processor 64-bit ARM

3. **Universal APK** - ~12MB
   - Kompatibel dengan SEMUA HP Android
   - Otomatis pilih architecture yang sesuai
   - **REKOMENDASI untuk pemula**

### Features:
- ✅ **Offline Support**
- ✅ **Progressive Web App**
- ✅ **Native Android Integration**
- ✅ **Dark Theme with Gold Accents**
- ✅ **Splash Screen**
- ✅ **Status Bar Customization**
- ✅ **Hardware Back Button**

---

## 🎉 Selamat!

Anda berhasil membuat APK Android asli dari PWA LeonX77!

### Apa yang Sudah Anda Pelajari:
1. ✅ Membuat repository GitHub
2. ✅ Upload file PWA
3. ✅ Setup GitHub Actions
4. ✅ Build APK otomatis
5. ✅ Install APK di Android
6. ✅ Update dan maintenance

### Next Steps:
- Customize app sesuai kebutuhan
- Publish ke Play Store (opsional)
- Share APK ke teman-teman
- Buat PWA lain dan convert ke APK

**Total waktu**: 30-45 menit untuk pemula
**Hasil**: APK Android asli yang siap pakai!

---

## 📞 Bantuan Tambahan

Jika masih bingung:
1. Screenshot error yang muncul
2. Cek apakah semua langkah sudah diikuti
3. Pastikan internet stabil saat build
4. Coba ulangi dari step yang error

**Remember**: APK hanya akan muncul SETELAH build di GitHub Actions selesai! 💀